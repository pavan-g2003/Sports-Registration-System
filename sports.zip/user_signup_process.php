<?php
include('db_connection.php'); // Ensure this file is correctly set up for database connection.

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $mobilenumber = trim($_POST['mobilenumber']);
    $password = trim($_POST['password']);

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Use a prepared statement to prevent SQL injection
    $query = "INSERT INTO user_credentials (username, email, mobilenumber, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param('ssss', $username, $email, $mobilenumber, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='user_login.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Error: Could not prepare the statement.');</script>";
    }

    $conn->close();
}
?>
